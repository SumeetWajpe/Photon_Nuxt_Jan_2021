var express = require('express');
var app = express();
var router = express.Router();
router.route('/products').get((req,res)=>{
    var products = [
        {
          id: 1,
          title: "Laptop",
          price: 50000,
          quantity: 100,
          rating: 4,
          ImageUrl:
            "https://media.wired.com/photos/5e911353798a15000821fedc/16:9/w_1311,h_737,c_limit/Gear-XPS-13-open-right-SOURCE-Dell.jpg",
          likes: 100,
        },
        {
          id: 2,
          title: "OLED TV",
          price: 25000,
          quantity: 0,
          rating: 3,
          ImageUrl:
            "https://cnet1.cbsistatic.com/img/SLxQWUH6B2ArLZNflKe3FR1AMAc=/1200x675/2016/09/02/c5ee11e2-3c27-45be-85a8-04b31f3a378a/philips-901f-oled-4k-ambilight-tv-6.jpg",
          likes: 500,
        },
        {
          id: 3,
          title: "Desktop",
          price: 10000,
          quantity: 200,
          rating: 3,
          ImageUrl:
            "https://i.pcmag.com/imagery/reviews/05zKVE4qnORysT6djhLeZZd-41.1578361275.fit_lpad.size_625x365.jpg",
          likes: 200,
        },
        {
          id: 4,
          title: "Mobile",
          price: 20000,
          quantity: 1000,
          rating: 5,
          ImageUrl: "https://static.toiimg.com/photo/73078527.cms",
          likes: 400,
        },
        {
          id: 5,
          title: "Camera",
          price: 90000,
          quantity: 0,
          rating: 4,
          ImageUrl:
            "https://2.img-dpreview.com/files/p/E~TS940x788~articles/3875106732/NikonZ6-fancy03b.jpeg",
          likes: 100,
        },
      ];

      res.json(products)
});
app.use('/',router);
app.use((req,res)=>{
    res.statusCode = 404;
    console.log('Not found !')
});
app.listen(5000,()=>{
    console.log('Server running at localhost:5000 !')
})