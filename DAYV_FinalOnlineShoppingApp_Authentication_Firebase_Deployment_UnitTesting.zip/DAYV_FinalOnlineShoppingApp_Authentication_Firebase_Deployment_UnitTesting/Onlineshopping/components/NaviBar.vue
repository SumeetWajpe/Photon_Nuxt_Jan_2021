<template>
    <div>
 <b-nav pills>
    <b-nav-item >
        <nuxt-link to="/">Home</nuxt-link>
    </b-nav-item>
     <b-nav-item >
        <nuxt-link to="/firebaseproducts">Products (Firebase)</nuxt-link>
    </b-nav-item>
    <b-nav-item >
        <nuxt-link to="/newproduct">New Product (Firebase)</nuxt-link>
    </b-nav-item>
    <b-nav-item >
        <nuxt-link to="/posts">Posts</nuxt-link>
    </b-nav-item>
    <b-nav-item >
        <nuxt-link to="/productsasyncdata">Products (asyncData)</nuxt-link>
    </b-nav-item>
    <b-nav-item >
        <nuxt-link to="/users">Users</nuxt-link>
    </b-nav-item>
    <b-nav-item v-if="!$store.state.isUserAuthenticated" >
        <nuxt-link to="/signin">Sign In</nuxt-link>
    </b-nav-item>
      <b-nav-item v-if="$store.state.isUserAuthenticated" >
        <a @click="SignOut"> Sign Out</a>
    </b-nav-item>
    <!-- <b-nav-item>Another Link</b-nav-item> -->
   
  </b-nav>
    </div>
</template>

<script>
import firebase from 'firebase/app';
import 'firebase/auth';

    export default {
        name:'NaviBar',
        methods:{
            SignOut(){
                firebase.auth().signOut();
                this.$store.dispatch('setAuthentication',false);
                this.$router.push('/signin');
            }
        }
    }
</script>

<style scoped>
    .nuxt-link-exact-active{
        background-color: turquoise;  
        margin: 5px;
        padding: 10px;      
    }
</style>