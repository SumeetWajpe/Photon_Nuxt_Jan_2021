<template>
    <div>
        <b-button variant="outline-primary">
            <b-icon icon="cart-fill"></b-icon>
            <nuxt-link to="/summary"> Current Items :  </nuxt-link> {{$store.getters.cartLength}}
        </b-button>
    </div>
</template>

<script>
    export default {
        
    }
</script>

<style scoped>
div{
    color:white;
    margin-bottom: 20px;
}

</style>