import axios from "axios";

export const state = () => ({
  currentItems: [],
  posts: [],
  users: [],
  firebaseproducts:[],
  isUserAuthenticated :false
});

export const getters = {
  cartLength(state) {
    return state.currentItems.length;
  }
};

export const actions = {
  // this gets executed on the Server
  async nuxtServerInit({ dispatch }) {
    await dispatch("fetchusers");
    await dispatch('fetchfirebaseproducts');
  },
  setAuthentication({commit},payload){
    commit('setAuthentication',payload)
  },
  fetchfirebaseproducts({ commit }) {
   return axios.get("https://photonnuxtapp-default-rtdb.firebaseio.com/products.json")
    .then(
      response =>{
        const productsArray = [];
        for(const key in response.data){
          productsArray.push({...response.data[key],id:key})
        }
        commit('fetchfirebaseproducts',productsArray);
      }
    )
  },
  fetchposts({ commit }) {
    axios.get("https://jsonplaceholder.typicode.com/posts").then(
      response => commit("fetchposts", response.data),
      err => console.log(err)
    );
  },
  fetchusers({ commit }) {
    return axios.get("https://jsonplaceholder.typicode.com/users").then(
      response => commit("fetchusers", response.data),
      err => console.log(err)
    );
  },
  addToCart({ commit }, payload) {
    commit("addToCart", payload);
  },
  addProductToFirebase({ commit }, payload) {
   return axios
      .post(
        "https://photonnuxtapp-default-rtdb.firebaseio.com/products.json",
        payload
      )
      .then(
        res => commit('addProductToFirebase',res.data),
        err => console.log(err)
      );
  }
};

export const mutations = {
  setAuthentication(state,payload){
    state.isUserAuthenticated = payload;
  },
  addProductToFirebase(state, payload) {
    state.firebaseproducts.push(payload);
  },
  fetchfirebaseproducts(state, payload) {
    state.firebaseproducts = payload;
  },
  fetchposts(state, payload) {
    state.posts = payload;
  },
  fetchusers(state, payload) {
    state.users = payload;
  },
  addToCart(state, payload) {
    state.currentItems.push(payload);
  },
  deleteProduct(state, payload) {
    let index = this.products.findIndex(p => p.id == payload);
    state.products.splice(index, 1);
  }
};
