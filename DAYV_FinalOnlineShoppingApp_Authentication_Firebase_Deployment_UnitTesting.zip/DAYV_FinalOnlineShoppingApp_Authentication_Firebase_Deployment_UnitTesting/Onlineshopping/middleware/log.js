export default function(theContext) {
    console.log('[Middleware::log] executed !');
    // getting the userAgent !
    // authenticate user / authorize users
}