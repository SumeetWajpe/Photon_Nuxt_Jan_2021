export default function (theContext) {
    // authentication middleware !
    if(!theContext.store.state.isUserAuthenticated){
        theContext.redirect('/signin')
    }
}