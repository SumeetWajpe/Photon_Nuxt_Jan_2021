export { default as Cartitems } from '../..\\components\\cartitems.vue'
export { default as Footer } from '../..\\components\\footer.vue'
export { default as Header } from '../..\\components\\header.vue'
export { default as Logo } from '../..\\components\\Logo.vue'
export { default as NaviBar } from '../..\\components\\NaviBar.vue'
export { default as Product } from '../..\\components\\product.vue'
export { default as Shoppingcart } from '../..\\components\\shoppingcart.vue'

export const LazyCartitems = import('../..\\components\\cartitems.vue' /* webpackChunkName: "components/cartitems" */).then(c => c.default || c)
export const LazyFooter = import('../..\\components\\footer.vue' /* webpackChunkName: "components/footer" */).then(c => c.default || c)
export const LazyHeader = import('../..\\components\\header.vue' /* webpackChunkName: "components/header" */).then(c => c.default || c)
export const LazyLogo = import('../..\\components\\Logo.vue' /* webpackChunkName: "components/logo" */).then(c => c.default || c)
export const LazyNaviBar = import('../..\\components\\NaviBar.vue' /* webpackChunkName: "components/navi-bar" */).then(c => c.default || c)
export const LazyProduct = import('../..\\components\\product.vue' /* webpackChunkName: "components/product" */).then(c => c.default || c)
export const LazyShoppingcart = import('../..\\components\\shoppingcart.vue' /* webpackChunkName: "components/shoppingcart" */).then(c => c.default || c)
