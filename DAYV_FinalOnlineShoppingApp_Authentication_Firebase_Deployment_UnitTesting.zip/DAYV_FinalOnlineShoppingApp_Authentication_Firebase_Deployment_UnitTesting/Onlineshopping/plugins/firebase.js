import firebase from 'firebase/app';
import 'firebase/auth';

var firebaseConfig = {
    apiKey: "AIzaSyDuQMLHSFL5scsEpE4f8sH2JkbDEnuACOA",
    authDomain: "photonnuxtapp.firebaseapp.com",
    databaseURL: "https://photonnuxtapp-default-rtdb.firebaseio.com",
    projectId: "photonnuxtapp",
    storageBucket: "photonnuxtapp.appspot.com",
    messagingSenderId: "444396111389",
    appId: "1:444396111389:web:3eeb834f3aa24d938068f4",
    measurementId: "G-BVMJ7Y9ME8"
  };

  let app = null;
  if(!firebase.apps.length){
      app = firebase.initializeApp(firebaseConfig);
  }

  export default firebase;
