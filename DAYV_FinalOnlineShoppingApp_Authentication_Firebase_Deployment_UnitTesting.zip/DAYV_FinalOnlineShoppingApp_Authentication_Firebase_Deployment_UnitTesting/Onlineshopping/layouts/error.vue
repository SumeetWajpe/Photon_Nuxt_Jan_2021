<template>
    <div class="container">
        <b-icon icon="exclamation-triangle-fill" font-scale="5"></b-icon>
        <h1> {{error.statusCode}} ! </h1>
        <h1> {{error.message}} ! </h1>

    </div>
</template>

<script>
    export default {
        layout:'errorlayout',
        props:['error']
    }
</script>

<style scoped>
 .container {
  margin: auto;  
  padding: 25px 0;
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  min-height: 100vh;
}
</style>