<template>
    <div class="_container">
        <h1>Post Details for {{$route.params.id}} (_id.vue) </h1>
        <h2>{{thePost.title}}</h2>
    </div>
</template>

<script>
    export default {
        name:'PostDetails',
        data(){

            return {
                thePost:{}
            }
        },
        mounted(){
           let theIndex = this.$store.state.posts.findIndex(p=>p.id == this.$route.params.id)
           this.thePost = this.$store.state.posts[theIndex];
        }
    }
</script>

<style>

</style>