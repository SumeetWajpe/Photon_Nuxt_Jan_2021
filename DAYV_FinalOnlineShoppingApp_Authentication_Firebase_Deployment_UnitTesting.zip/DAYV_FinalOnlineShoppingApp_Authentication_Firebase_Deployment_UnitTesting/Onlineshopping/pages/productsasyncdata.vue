<template>
    <div class="container">
        <h1> Posts (asyncData) </h1>
        <ul>
            <li v-for="p in products" :key="p">{{p.title}}</li>
        </ul>
    </div>
</template>

<script>
 import axios from 'axios'
    export default {
  middleware:'auth',

        data(){
            return {
                products:[]
            }
        },
        // asyncData(){
        //   return   axios.get('http://localhost:5000/products')
        //     .then(res=>{
        //         return {products:res.data}
        //     });
        // }
        async asyncData(context){
            try {
                let productsResponse = await axios.get('http://localhost:5000/products')
                return  {products:productsResponse.data} 
            } catch (error) {
               context.error({
                   message:'Unable to connect'
               });
            }
        }
    }
</script>

<style scoped>

</style>