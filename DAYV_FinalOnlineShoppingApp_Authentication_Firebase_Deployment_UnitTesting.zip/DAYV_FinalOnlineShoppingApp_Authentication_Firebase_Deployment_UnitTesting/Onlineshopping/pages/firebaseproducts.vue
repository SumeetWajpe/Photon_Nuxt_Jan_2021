<template>
  <div class="_container">
    <div class="row">
      <div
        class="col-md-3"
        v-for="product in $store.state.firebaseproducts"
        :key="product.id"
      >
        <b-card
          :title="product.title"
          :img-src="product.ImageUrl"
          :img-alt="product.title"
          img-top
          tag="article"
          style="max-width: 20rem"
          class="mb-2"
        >
          <b-card-text>
            {{ product.price }}
          </b-card-text>
        </b-card>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  middleware:'auth',

};
</script>

<style scoped>
</style>