<template>
  <div class="container">
   
      <b-card
        border-variant="primary"
        header="Summary"
        header-bg-variant="primary"
        header-text-variant="white"
        align="center"
      >
        <b-card no-body v-for="product in $store.state.currentItems" :key="product.id" class="overflow-hidden" style="max-width: 540px">
          <b-row no-gutters>
            <b-col md="6">
              <b-card-img
                :src="product.ImageUrl"
                :alt="product.title"
                class="rounded-0"
              ></b-card-img>
            </b-col>
            <b-col md="6">
              <b-card-body :title="product.title">
                <b-card-text>
                 {{product.price}}
                </b-card-text>
                <b-button variant="outline-danger">
                    <b-icon icon="trash-fill"></b-icon>
                </b-button>
              </b-card-body>
            </b-col>
          </b-row>
        </b-card>
     
      </b-card>
   

  </div>
</template>

<script>
export default {
  middleware:'auth',

};
</script>

<style scoped>

</style>