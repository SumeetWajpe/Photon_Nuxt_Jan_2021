<template>
  <div class="container">
    <h1>All Posts (pages/posts.vue)</h1>

    <div class="row">
      <div class="col-md-6" style="border:1px solid gray;border-radius:5px;">
        <ul>
          <li v-for="post in $store.state.posts" :key="post.id">
            <!-- <nuxt-link :to="{name:'postdetails',params:{id:post.id}}"> {{post.title}}</nuxt-link>  -->
            <nuxt-link :to="`/posts/${post.id}`"> {{ post.title }}</nuxt-link>
          </li>          
        </ul>       
      </div>
      <div class="col-md-6" style="border:1px solid gray;border-radius:5px">
        <NuxtChild :key="$route.params.id" />
      </div>
    </div>
  </div>
</template>

<script>
import { mapActions } from "vuex";
export default {
  middleware:'auth',
  methods: {
    ...mapActions(["fetchposts"]),
  },
  mounted() {
    this.fetchposts();
  },
};
</script>

<style scoped>
</style>