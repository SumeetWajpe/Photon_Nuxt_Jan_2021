import Counter from "@/components/Counter.vue";
import { mount, shallowMount } from "@vue/test-utils";

const factory = () => shallowMount(Counter);

describe("tests for Counter", () => {
  // test cases
  test("is a Vue instance", () => {
    const wrapper = mount(Counter);
    expect(wrapper.vm).toBeTruthy();
  });

  test("the initial count to be 0", () => {
    const wrapper = factory();
    expect(wrapper.vm.$data.count).toBe(0);
  });

  test("the button click to call handler", () => {
    const handleClickMock = jest.spyOn(Counter.methods, "CalledOnClick");
    const wrapper = factory();
    wrapper.find("button").trigger("click");
    expect(handleClickMock).toHaveBeenCalled();
    handleClickMock.mockRestore();
  });

  test('renders Counter with Snapshot',()=>{
    const wrapper = factory();
    expect(wrapper.html()).toMatchSnapshot();
  })
});
