<template>
    <div>
        <strong>Count : {{count}}</strong>
        <button @click="CalledOnClick">
            +++
        </button>
    </div>
</template>

<script>
    export default {
        data(){
            return {
                count:0
            }
        },methods:{
            CalledOnClick(){
                this.count++
            }
        }
    }
</script>

<style scoped>

</style>