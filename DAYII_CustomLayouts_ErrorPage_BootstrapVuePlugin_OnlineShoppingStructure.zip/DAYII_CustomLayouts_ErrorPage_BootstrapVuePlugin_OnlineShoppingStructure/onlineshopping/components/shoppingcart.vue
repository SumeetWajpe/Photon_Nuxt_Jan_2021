<template>
    <div>
        <h1>Shopping Cart </h1>
        <div v-for="product in products" :key="product">
            <Product :productdetails="product" />
        </div>
    </div>
</template>

<script>
import Product from './product';

    export default {
        name:'ShoppingCart',
        data(){
            return {
                products:['Mobile','LED TV','Laptop']
            }
        }
    }
</script>

<style scoped>

</style>