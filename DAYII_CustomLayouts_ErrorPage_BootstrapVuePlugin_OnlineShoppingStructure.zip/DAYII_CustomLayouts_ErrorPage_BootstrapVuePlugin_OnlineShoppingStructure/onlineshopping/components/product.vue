<template>
    <div>
        <h2>{{productdetails}} </h2>
    </div>
</template>

<script>
    export default {
        name:'Product',
        props:['productdetails']

    }
</script>

<style scoped>

</style>