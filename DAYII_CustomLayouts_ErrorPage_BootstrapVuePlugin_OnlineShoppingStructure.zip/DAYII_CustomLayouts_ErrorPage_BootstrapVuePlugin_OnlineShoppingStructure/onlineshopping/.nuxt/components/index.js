export { default as Logo } from '../..\\components\\Logo.vue'
export { default as Product } from '../..\\components\\product.vue'
export { default as Shoppingcart } from '../..\\components\\shoppingcart.vue'

export const LazyLogo = import('../..\\components\\Logo.vue' /* webpackChunkName: "components_Logo" */).then(c => c.default || c)
export const LazyProduct = import('../..\\components\\product.vue' /* webpackChunkName: "components_product" */).then(c => c.default || c)
export const LazyShoppingcart = import('../..\\components\\shoppingcart.vue' /* webpackChunkName: "components_shoppingcart" */).then(c => c.default || c)
