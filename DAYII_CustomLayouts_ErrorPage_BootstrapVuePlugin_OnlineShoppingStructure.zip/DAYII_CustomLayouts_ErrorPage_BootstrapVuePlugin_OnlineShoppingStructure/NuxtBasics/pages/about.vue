<template>
    <div>
        <h2> About Us ! </h2>
    </div>
</template>

<script>
    export default {
        
    }
</script>

<style scoped>

</style>