<template>
  <div class="container">
    <div>
      

      <img src="@/assets/react.png" height="200" width="200" />
      <hr/>
      <img src="~/static/mdb-react.png" height="200" width="200"  />
     <hr/>
      <div id="targetBackground">
        dfgdfgfdgd
      </div>
      <hr/>
       <img :src="images[0]" height="200" width="200" />
      <hr/>
      <img :src="images[1]" height="200" width="200"  />
     <hr/>


      <button class="btn btn-success">Bootstraped !</button>
      <h1 class="title">
        nuxthello
      </h1>
     
    </div>
  </div>
</template>

<script>
export default {
  data(){
    return{
      images:[`${require('~/assets/react.png')}`,'mdb-react.png']
    }
  }
}
</script>

<style>
#targetBackground{
  margin:0px auto;
  height: 200px;
  width:300px;
  background-image: url('~@/static/mdb-react.png');
}

.container {
  margin: 0 auto;
  min-height: 100vh;
  display: flex;
  justify-content: center;
  align-items: center;
  text-align: center;
}

.title {
  font-family:
    'Quicksand',
    'Source Sans Pro',
    -apple-system,
    BlinkMacSystemFont,
    'Segoe UI',
    Roboto,
    'Helvetica Neue',
    Arial,
    sans-serif;
  display: block;
  font-weight: 300;
  font-size: 100px;
  color: #35495e;
  letter-spacing: 1px;
}

.subtitle {
  font-weight: 300;
  font-size: 42px;
  color: #526488;
  word-spacing: 5px;
  padding-bottom: 15px;
}

.links {
  padding-top: 15px;
}
</style>
