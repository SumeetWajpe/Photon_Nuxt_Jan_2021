<template>
  <div >
    <div class="footer" :style="{'background-color':bgcolor}">Copyright @2021 Online Training</div>
  </div>
</template>

<script>
export default {
    name:'Footer',
    props:['bgcolor']

};
</script>

<style scoped>
.footer {
  position: fixed;
  bottom: 0;
  z-index: 10;
  height: 5%;
  padding: 30px;
  width: 100%;
  text-align: center;
  color: white;
}
</style>