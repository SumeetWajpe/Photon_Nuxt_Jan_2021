<template>
  <div :style="{ 'background-color' :bgcolor}">
    <div class="header">
      <h1>Header from Layout !</h1>
    </div>    
  </div>
</template>

<script>
export default {
    name:'Header',
    props:['bgcolor']
};
</script>

<style>




</style>