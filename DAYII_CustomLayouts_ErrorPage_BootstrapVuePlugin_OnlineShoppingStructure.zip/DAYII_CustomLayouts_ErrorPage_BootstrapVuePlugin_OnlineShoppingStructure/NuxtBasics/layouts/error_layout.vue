<template>
  <div>
    <Header />
      <Nuxt />
    <Footer />
  </div>
</template>

<script>
export default {};
</script>

<style scoped>

</style>