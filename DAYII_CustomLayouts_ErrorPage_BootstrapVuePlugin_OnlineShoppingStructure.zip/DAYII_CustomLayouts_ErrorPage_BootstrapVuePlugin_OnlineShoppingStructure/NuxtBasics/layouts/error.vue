<template>
    <div>
       404 Error !
    </div>
</template>

<script>
    export default {
        layout:'error_layout'
    }
</script>

<style scoped>

</style>