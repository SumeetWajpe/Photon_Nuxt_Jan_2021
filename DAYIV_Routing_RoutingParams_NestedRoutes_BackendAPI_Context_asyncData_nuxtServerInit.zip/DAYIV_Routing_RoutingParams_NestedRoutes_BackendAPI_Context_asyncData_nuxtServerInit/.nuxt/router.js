import Vue from 'vue'
import Router from 'vue-router'
import { normalizeURL, decode } from '@nuxt/ufo'
import { interopDefault } from './utils'
import scrollBehavior from './router.scrollBehavior.js'

const _86f3782e = () => interopDefault(import('..\\pages\\postdetails_.vue' /* webpackChunkName: "pages/postdetails_" */))
const _1fbe8a97 = () => interopDefault(import('..\\pages\\posts.vue' /* webpackChunkName: "pages/posts" */))
const _0e53fbea = () => interopDefault(import('..\\pages\\posts\\index.vue' /* webpackChunkName: "pages/posts/index" */))
const _1d830b33 = () => interopDefault(import('..\\pages\\posts\\_id.vue' /* webpackChunkName: "pages/posts/_id" */))
const _a9a91ef4 = () => interopDefault(import('..\\pages\\productsasyncdata.vue' /* webpackChunkName: "pages/productsasyncdata" */))
const _3325527a = () => interopDefault(import('..\\pages\\resource.vue' /* webpackChunkName: "pages/resource" */))
const _0dcdd9ea = () => interopDefault(import('..\\pages\\summary.vue' /* webpackChunkName: "pages/summary" */))
const _86cf0b68 = () => interopDefault(import('..\\pages\\users.vue' /* webpackChunkName: "pages/users" */))
const _3a8ca86f = () => interopDefault(import('..\\pages\\userdetails\\_id.vue' /* webpackChunkName: "pages/userdetails/_id" */))
const _772ea016 = () => interopDefault(import('..\\pages\\index.vue' /* webpackChunkName: "pages/index" */))

// TODO: remove in Nuxt 3
const emptyFn = () => {}
const originalPush = Router.prototype.push
Router.prototype.push = function push (location, onComplete = emptyFn, onAbort) {
  return originalPush.call(this, location, onComplete, onAbort)
}

Vue.use(Router)

export const routerOptions = {
  mode: 'history',
  base: '/',
  linkActiveClass: 'nuxt-link-active',
  linkExactActiveClass: 'nuxt-link-exact-active',
  scrollBehavior,

  routes: [{
    path: "/postdetails_",
    component: _86f3782e,
    name: "postdetails_"
  }, {
    path: "/posts",
    component: _1fbe8a97,
    children: [{
      path: "",
      component: _0e53fbea,
      name: "posts"
    }, {
      path: ":id",
      component: _1d830b33,
      name: "posts-id"
    }]
  }, {
    path: "/productsasyncdata",
    component: _a9a91ef4,
    name: "productsasyncdata"
  }, {
    path: "/resource",
    component: _3325527a,
    name: "resource"
  }, {
    path: "/summary",
    component: _0dcdd9ea,
    name: "summary"
  }, {
    path: "/users",
    component: _86cf0b68,
    name: "users"
  }, {
    path: "/userdetails/:id?",
    component: _3a8ca86f,
    name: "userdetails-id"
  }, {
    path: "/",
    component: _772ea016,
    name: "index"
  }],

  fallback: false
}

function decodeObj(obj) {
  for (const key in obj) {
    if (typeof obj[key] === 'string') {
      obj[key] = decode(obj[key])
    }
  }
}

export function createRouter () {
  const router = new Router(routerOptions)

  const resolve = router.resolve.bind(router)
  router.resolve = (to, current, append) => {
    if (typeof to === 'string') {
      to = normalizeURL(to)
    }
    const r = resolve(to, current, append)
    if (r && r.resolved && r.resolved.query) {
      decodeObj(r.resolved.query)
    }
    return r
  }

  return router
}
