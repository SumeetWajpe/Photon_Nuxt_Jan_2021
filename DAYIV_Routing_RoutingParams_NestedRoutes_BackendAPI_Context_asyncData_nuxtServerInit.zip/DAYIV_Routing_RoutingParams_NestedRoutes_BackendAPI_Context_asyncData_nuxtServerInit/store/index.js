import axios from 'axios';

export const state = ()=>({
    currentItems:[],
    posts:[],
    users:[]
});

export const getters = {
    cartLength(state){
        return state.currentItems.length 
    }    
}

export const actions = { 
  // this gets executed on the Server
  async nuxtServerInit({dispatch}){
    await dispatch('fetchusers');
  },
  fetchposts({commit}){
      axios.get('https://jsonplaceholder.typicode.com/posts').then(
        (response)=>commit('fetchposts',response.data),
        (err)=>console.log(err)
    )      
    }  ,
    fetchusers({commit}){
     return axios.get('https://jsonplaceholder.typicode.com/users').then(
        (response)=>commit('fetchusers',response.data),
        (err)=>console.log(err)
    )      
    } ,
    addToCart({commit},payload){
      commit('addToCart',payload)
  }
}


export const mutations = {
  fetchposts(state,payload){
    state.posts = payload;
  },
  fetchusers(state,payload){
    state.users = payload;
  },
    addToCart(state,payload){
        state.currentItems.push(payload)
    },
    deleteProduct(state,payload){
        let index = this.products.findIndex((p) => p.id == payload);          
        state.products.splice(index,1)
    }
}