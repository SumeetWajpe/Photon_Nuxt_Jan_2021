<template>
    <div>
        <h1>Post Details for {{$route.params.id}} </h1>
    </div>
</template>

<script>
    export default {
        name:'PostDetails'
    }
</script>

<style  scoped>

</style>