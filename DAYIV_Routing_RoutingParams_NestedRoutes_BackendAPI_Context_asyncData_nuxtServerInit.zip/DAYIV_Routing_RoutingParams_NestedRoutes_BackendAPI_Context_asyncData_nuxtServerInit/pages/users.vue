<template>
  <div class="container">
    <h1>All Users</h1>
        <ul>
          <li v-for="user in $store.state.users" :key="user.id">
             <nuxt-link :to="`/userdetails/${user.id}`"> {{ user.name }}</nuxt-link>
          </li>          
        </ul>    
  </div>
</template>

<script>
import { mapActions } from "vuex";
export default {
  methods: {
    ...mapActions(["fetchusers"]),
  },
  mounted() {
    this.fetchusers();
  },
};
</script>

<style scoped>
</style>