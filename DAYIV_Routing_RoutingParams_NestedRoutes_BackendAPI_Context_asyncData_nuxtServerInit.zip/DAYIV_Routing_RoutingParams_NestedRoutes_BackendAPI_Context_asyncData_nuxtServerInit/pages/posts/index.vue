<template>
    <div>
        <b-alert variant="primary" show>
            <strong>Please select a post for details !</strong>

        </b-alert>
    </div>
</template>

<script>
    export default {
        
    }
</script>

<style scoped>

</style>