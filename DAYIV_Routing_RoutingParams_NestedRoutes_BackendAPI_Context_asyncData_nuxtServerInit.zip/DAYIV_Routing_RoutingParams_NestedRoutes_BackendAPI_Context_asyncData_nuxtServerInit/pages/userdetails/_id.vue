<template>
    <div class="container">
        <h1>User Details for {{$route.params.id}} (_id.vue) </h1>
        <h2>{{theUser.name}}</h2>
    </div>
</template>

<script>
    export default {
        name:'UserDetails',
        data(){

            return {
                theUser:{}
            }
        },
        mounted(){
           let theIndex = this.$store.state.users.findIndex(u=>u.id == this.$route.params.id)
           this.theUser = this.$store.state.users[theIndex];
        }
    }
</script>

<style  scoped>

</style>