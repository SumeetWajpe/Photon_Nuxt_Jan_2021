<template>
    <div >

        <div class="header">Resource Not Found !</div>
        <div>
            <Nuxt/>
        </div>
        
        <div class="footer">@Error 2021</div>
        
    </div>
</template>

<script>
    export default {
        
    }
</script>

<style scoped>
.header{    
    top:0;left:0;z-index:10;
    height: 8%;
        padding: 30px;
    width:100%;   
    text-align: center;color:white;    
       background-color: red;

}
.footer{
    position: fixed;
    bottom:0;left:0;
    height: 5%;
    width:100%;   
    text-align: center;color:white;    
    background-color: red;
    padding: 10px;
}
</style>