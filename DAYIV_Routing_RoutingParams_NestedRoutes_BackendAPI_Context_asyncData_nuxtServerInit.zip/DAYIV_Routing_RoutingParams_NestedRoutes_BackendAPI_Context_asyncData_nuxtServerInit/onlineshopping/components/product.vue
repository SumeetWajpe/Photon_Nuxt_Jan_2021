<template>
  <div>
     <b-card
    :title="productdetails.title"
    :img-src="productdetails.ImageUrl"
    img-alt="productdetails.title"
    img-top
    tag="article"
    style="max-width: 20rem;"
    class="mb-2"
  >
          <b-card-text>
        Price : {{ productdetails.price | currency("₹") }}
      </b-card-text>
      <b-card-text>
        Rating : <b-icon v-for="(i,index) in productdetails.rating" :key="index" icon="star-fill"></b-icon>
      </b-card-text>
      <b-card-text>
        In Stock : {{ productdetails.quantity }}
      </b-card-text>

      <b-button variant="outline-primary">
          <b-icon icon="hand-thumbs-up" animation="throb"></b-icon>
          {{productdetails.likes}}
      </b-button>
      <b-button variant="warning" @click="addToCart"><b-icon icon="cart4"></b-icon>  Add to cart </b-button>

  </b-card>
  </div>
</template>

<script>
import { mapMutations } from 'vuex';

export default {
  name: "Product",
  props: {
    productdetails: Object,
  },
  
  
  methods: {
   
    addToCart(){
        this.$store.dispatch('addToCart',this.productdetails)
    }
  },
  filters: {
    currency(value, args) {
      return ` ${args}${value}`;
    },
  }
};
</script>

<style scoped>
</style>