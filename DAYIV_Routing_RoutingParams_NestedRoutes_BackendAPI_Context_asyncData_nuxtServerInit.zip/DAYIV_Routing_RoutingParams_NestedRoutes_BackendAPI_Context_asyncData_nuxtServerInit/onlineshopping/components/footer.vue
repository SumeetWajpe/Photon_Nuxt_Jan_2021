<template>
  <div id="footer">
    
    @Copyright 2021 Online Training
  </div>
</template>

<script>
export default {
  name: "Footer",
};
</script>

<style scoped>
#footer{
    position: fixed;
    bottom:0;left:0;
    height: 5%;
    width:100%;   
    text-align: center;color:white;    
    background-color: #386fd4;
    padding: 10px;
}
</style>