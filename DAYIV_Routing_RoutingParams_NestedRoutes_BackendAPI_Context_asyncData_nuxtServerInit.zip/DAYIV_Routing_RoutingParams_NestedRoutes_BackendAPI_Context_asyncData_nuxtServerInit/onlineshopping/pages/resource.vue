<template>
    <div>

    </div>
</template>

<script>
    export default {
        transitions:'resource'
    }
</script>

<style scoped>

</style>