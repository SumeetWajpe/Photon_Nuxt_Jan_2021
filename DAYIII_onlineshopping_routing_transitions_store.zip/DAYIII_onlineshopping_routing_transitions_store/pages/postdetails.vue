<template>
    <div>
        <h1>Post Details </h1>
    </div>
</template>

<script>
    export default {
        name:'PostDetails'
    }
</script>

<style  scoped>

</style>