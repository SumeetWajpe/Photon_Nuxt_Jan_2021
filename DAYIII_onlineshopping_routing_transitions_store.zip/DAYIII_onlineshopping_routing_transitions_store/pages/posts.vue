<template>
    <div class="container">
        <h1>All Posts</h1>
        <ul>
            <li v-for="post in $store.state.posts" :key="post.id">
              <!-- <nuxt-link :to="{name:'postdetails',params:{id:post.id}}"> {{post.title}}</nuxt-link>  -->
              <nuxt-link :to="`/postdetails/${post.id}`"> {{post.title}}</nuxt-link> 

            </li>
        </ul>
    </div>
</template>

<script>
    import {mapActions} from 'vuex'
    export default {
        methods:{
            ...mapActions(['fetchposts'])
        }
        ,
        mounted(){
           this.fetchposts()
        }

    }
</script>

<style scoped>

</style>