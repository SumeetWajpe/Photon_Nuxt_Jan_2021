<template>
    <div class="container">
        <b-icon icon="exclamation-triangle-fill" font-scale="5"></b-icon>
        <h1> 404 ! Not found ! </h1>
    </div>
</template>

<script>
    export default {
        layout:'errorlayout'
    }
</script>

<style scoped>
 .container {
  margin: auto;  
  padding: 25px 0;
  display: flex;
  justify-content: center;
  align-items: center;
  min-height: 100vh;
}
</style>