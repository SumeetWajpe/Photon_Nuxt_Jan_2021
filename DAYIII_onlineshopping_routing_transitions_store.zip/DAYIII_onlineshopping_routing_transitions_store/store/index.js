import axios from 'axios';

export const state = ()=>({
    currentItems:[],
    posts:[],
   
});

export const getters = {
    cartLength(state){
        return state.currentItems.length 
    }    
}


export const actions = { 
  fetchposts({commit}){
      axios.get('https://jsonplaceholder.typicode.com/posts').then(
        (response)=>commit('fetchposts',response.data),
        (err)=>console.log(err)
    )      
    }  ,
    addToCart({commit},payload){
      commit('addToCart',payload)
  }
}


export const mutations = {
  fetchposts(state,payload){
    state.posts = payload;
  },
    addToCart(state,payload){
        state.currentItems.push(payload)
    },
    deleteProduct(state,payload){
        let index = this.products.findIndex((p) => p.id == payload);          
        state.products.splice(index,1)
    }
}