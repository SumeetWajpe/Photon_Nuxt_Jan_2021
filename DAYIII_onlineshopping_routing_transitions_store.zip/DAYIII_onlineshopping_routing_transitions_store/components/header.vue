<template>
  <div id="header">    
    <h1>Online Shopping</h1>
  </div>
</template>

<script>
export default {
  name: "Header",
};
</script>

<style scoped>
#header{    
    top:0;left:0;z-index:10;
    height: 8%;
        padding: 30px;
    width:100%;   
    text-align: center;color:white;    
       background-color: #38d493;

}
</style>