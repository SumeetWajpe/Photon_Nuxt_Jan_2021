import Vue from 'vue'
import Router from 'vue-router'
import { normalizeURL, decode } from '@nuxt/ufo'
import { interopDefault } from './utils'
import scrollBehavior from './router.scrollBehavior.js'

const _338cb57e = () => interopDefault(import('..\\pages\\postdetails.vue' /* webpackChunkName: "pages/postdetails" */))
const _77a9e79c = () => interopDefault(import('..\\pages\\posts.vue' /* webpackChunkName: "pages/posts" */))
const _6223a6ff = () => interopDefault(import('..\\pages\\resource.vue' /* webpackChunkName: "pages/resource" */))
const _492060c5 = () => interopDefault(import('..\\pages\\summary.vue' /* webpackChunkName: "pages/summary" */))
const _1b9b21b1 = () => interopDefault(import('..\\pages\\index.vue' /* webpackChunkName: "pages/index" */))

// TODO: remove in Nuxt 3
const emptyFn = () => {}
const originalPush = Router.prototype.push
Router.prototype.push = function push (location, onComplete = emptyFn, onAbort) {
  return originalPush.call(this, location, onComplete, onAbort)
}

Vue.use(Router)

export const routerOptions = {
  mode: 'history',
  base: '/',
  linkActiveClass: 'nuxt-link-active',
  linkExactActiveClass: 'nuxt-link-exact-active',
  scrollBehavior,

  routes: [{
    path: "/postdetails",
    component: _338cb57e,
    name: "postdetails"
  }, {
    path: "/posts",
    component: _77a9e79c,
    name: "posts"
  }, {
    path: "/resource",
    component: _6223a6ff,
    name: "resource"
  }, {
    path: "/summary",
    component: _492060c5,
    name: "summary"
  }, {
    path: "/",
    component: _1b9b21b1,
    name: "index"
  }],

  fallback: false
}

function decodeObj(obj) {
  for (const key in obj) {
    if (typeof obj[key] === 'string') {
      obj[key] = decode(obj[key])
    }
  }
}

export function createRouter () {
  const router = new Router(routerOptions)

  const resolve = router.resolve.bind(router)
  router.resolve = (to, current, append) => {
    if (typeof to === 'string') {
      to = normalizeURL(to)
    }
    const r = resolve(to, current, append)
    if (r && r.resolved && r.resolved.query) {
      decodeObj(r.resolved.query)
    }
    return r
  }

  return router
}
